# TEAM-SENTRY-FRONTEND

This is the main repo of the Team sentry Frontend Devolopers

*The master contains 5 branches for the five (5) different teams [Team A - E]*

Each sub-team lead [Team A,B,...] lead should create 5 folders which are:

# Footer and NavBar
# Page 1
# Page 2
# Page 3
# Page 4

*Each Team's branch should contain each of the 5 folders above*


# TO-CONTRIBUTE:


Clone Repo:
 
*Next*
Create a folder with your username and add to the folder:
  /Team A/page [number]

Add your HTML and CSS files to the folder which you have created

Example directory: /Team A/Page 1/[username]


*DON'T ADD YOUR SCRIPT TO THE ROOT DIRECTORY OF THIS PROJECT*

## NOTE:

Make your pages responsive
No framework but bootstrap is allowed
Do not commit to the master branch
